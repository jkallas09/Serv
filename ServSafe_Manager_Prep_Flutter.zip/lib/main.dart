import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const PrepApp());

class Question {
  final String category, prompt, explanation;
  final List<String> options;
  final int correct;
  const Question(this.category, this.prompt, this.options, this.correct, this.explanation);
}

const questions = <Question>[
  Question('Time & Temperature', 'What is the minimum internal cooking temperature for poultry?', ['135°F (57°C)', '145°F (63°C)', '155°F (68°C)', '165°F (74°C)'], 3, 'Poultry must reach at least 165°F (74°C).'),
  Question('Time & Temperature', 'What is the cold-holding limit for TCS food?', ['32°F (0°C)', '41°F (5°C)', '50°F (10°C)', '70°F (21°C)'], 1, 'Cold-hold TCS food at 41°F (5°C) or lower.'),
  Question('Time & Temperature', 'What is the hot-holding minimum for TCS food?', ['120°F (49°C)', '125°F (52°C)', '135°F (57°C)', '145°F (63°C)'], 2, 'Hot-hold TCS food at 135°F (57°C) or higher.'),
  Question('Time & Temperature', 'How quickly must cooked TCS food cool from 135°F to 70°F?', ['Within 1 hour', 'Within 2 hours', 'Within 4 hours', 'Within 6 hours'], 1, 'The first cooling stage must happen within 2 hours.'),
  Question('Time & Temperature', 'What is the total maximum cooling time from 135°F to 41°F?', ['2 hours', '4 hours', '6 hours', '8 hours'], 2, 'Cool from 135°F to 70°F within 2 hours and to 41°F within 6 hours total.'),
  Question('Time & Temperature', 'What temperature is required to reheat TCS food for hot holding?', ['135°F for 15 seconds', '145°F for 15 seconds', '155°F for 15 seconds', '165°F for 15 seconds'], 3, 'Reheat previously cooked and cooled TCS food to 165°F for 15 seconds within 2 hours.'),
  Question('Personal Hygiene', 'When must a food handler wash their hands?', ['Only at the start of a shift', 'After handling raw meat', 'Only after breaks', 'Only when hands look dirty'], 1, 'Wash hands after handling raw animal foods and before switching tasks.'),
  Question('Personal Hygiene', 'Where should employees wash their hands?', ['Food-prep sink', 'Three-compartment sink', 'Designated handwashing sink', 'Mop sink'], 2, 'Use a dedicated handwashing sink, not food-prep or warewashing sinks.'),
  Question('Personal Hygiene', 'Which symptom generally requires excluding a food handler from the operation?', ['Mild headache', 'Vomiting', 'Dry skin', 'Sneezing once'], 1, 'Vomiting is a key symptom requiring exclusion under food safety rules.'),
  Question('Cross-Contamination', 'Where should raw poultry be stored in a shared refrigerator?', ['Above ready-to-eat food', 'On the top shelf', 'Below ready-to-eat foods and other raw meats', 'Next to washed produce'], 2, 'Store raw poultry below foods requiring lower cooking temperatures.'),
  Question('Cross-Contamination', 'What is the best way to prevent allergen cross-contact?', ['Remove visible crumbs only', 'Use cleaned and sanitized equipment', 'Cook all food longer', 'Store all allergens together'], 1, 'Clean and sanitize tools and surfaces and follow allergen-specific procedures.'),
  Question('Cleaning & Sanitizing', 'What is the correct sequence for cleaning and sanitizing a food-contact surface?', ['Sanitize, wash, rinse, dry', 'Wash, rinse, sanitize, air-dry', 'Rinse, sanitize, wash, dry', 'Wash, dry, sanitize, rinse'], 1, 'Wash, rinse, sanitize, then allow to air-dry.'),
  Question('Cleaning & Sanitizing', 'How should sanitizer concentration be checked?', ['By smell', 'By color alone', 'With an appropriate test kit or strips', 'By how much it foams'], 2, 'Use a test kit appropriate for the sanitizer and follow the label.'),
  Question('Foodborne Illness', 'Which population is at greater risk of foodborne illness?', ['Healthy adults only', 'Older adults', 'Professional athletes only', 'People who eat spicy food'], 1, 'Older adults, young children, and immunocompromised people are at higher risk.'),
  Question('Foodborne Illness', 'Which practice helps prevent norovirus spread?', ['Working while vomiting', 'Proper handwashing', 'Using gloves instead of washing hands', 'Rinsing hands with water only'], 1, 'Effective handwashing and excluding symptomatic workers reduce transmission.'),
  Question('Receiving & Storage', 'What should you do with a delivery of refrigerated TCS food received at an unsafe temperature?', ['Accept and cool it later', 'Reject the delivery', 'Mix it with colder food', 'Leave it on the dock'], 1, 'Reject food that fails receiving temperature requirements.'),
  Question('Receiving & Storage', 'What does FIFO stand for?', ['Food Is Fully Organized', 'First In, First Out', 'Fresh Items For Orders', 'First Inspection, Final Order'], 1, 'Use older stock first, while checking date marks and food condition.'),
  Question('Management', 'What is the main purpose of active managerial control?', ['Reduce menu variety', 'Prevent food safety hazards proactively', 'Eliminate all paperwork', 'Replace employee training'], 1, 'Managers identify risks, implement controls, monitor, and correct problems.'),
  Question('Management', 'Which is an example of a corrective action?', ['Ignoring a failed temperature check', 'Reheating improperly held food without evaluation', 'Discarding unsafe food and correcting the process', 'Waiting until the next inspection'], 2, 'Correct unsafe conditions promptly and prevent recurrence.'),
  Question('Management', 'What should a manager do when a food handler reports jaundice?', ['Ignore it if they feel fine', 'Follow exclusion and regulatory reporting requirements', 'Assign only cold food tasks', 'Have them wear extra gloves'], 1, 'Jaundice requires immediate management action and may require reporting to the regulatory authority.'),
];

class PrepApp extends StatelessWidget {
  const PrepApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'Food Manager Prep', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F72)), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0, completed = 0, correct = 0;
  final Map<String, List<int>> stats = {};
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      completed = prefs.getInt('completed') ?? 0;
      correct = prefs.getInt('correct') ?? 0;
      final raw = prefs.getString('stats');
      if (raw != null) {
        final parsed = jsonDecode(raw) as Map<String, dynamic>;
        stats.addAll(parsed.map((k, v) => MapEntry(k, List<int>.from(v as List))));
      }
    });
  }
  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('completed', completed);
    await prefs.setInt('correct', correct);
    await prefs.setString('stats', jsonEncode(stats));
  }
  void record(Question q, bool isCorrect) {
    setState(() {
      completed++;
      if (isCorrect) correct++;
      final counts = stats.putIfAbsent(q.category, () => [0, 0]);
      counts[0]++;
      if (isCorrect) counts[1]++;
    });
    save();
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Food Manager Prep')),
    body: SafeArea(child: IndexedStack(index: tab, children: [
      _dashboard(), QuizView(onAnswer: record), const FlashcardsView(), _progress(),
    ])),
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
      NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
      NavigationDestination(icon: Icon(Icons.quiz_outlined), label: 'Practice'),
      NavigationDestination(icon: Icon(Icons.style_outlined), label: 'Flashcards'),
      NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Progress'),
    ]),
  );
  Widget _dashboard() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Get exam-ready', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('Study food safety at your own pace, even offline.'),
    const SizedBox(height: 20), Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Your overall accuracy'), const SizedBox(height: 8),
      Text(completed == 0 ? 'Start practicing' : '${(100 * correct / completed).round()}%', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
      Text('$completed questions answered'),
    ]))),
    const SizedBox(height: 18), FilledButton.icon(onPressed: () => setState(() => tab = 1), icon: const Icon(Icons.play_arrow), label: const Text('Start practice test')),
    OutlinedButton.icon(onPressed: () => setState(() => tab = 2), icon: const Icon(Icons.style), label: const Text('Review flashcards')),
    const SizedBox(height: 24), const Text('Study topics', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    ...questions.map((e) => e.category).toSet().map((c) => ListTile(leading: const Icon(Icons.menu_book_outlined), title: Text(c))),
    const SizedBox(height: 20), const Text('Independent study aid. Not affiliated with or endorsed by ServSafe or the National Restaurant Association.', style: TextStyle(fontSize: 12)),
  ]);
  Widget _progress() => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Study progress', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10), Text('$correct correct out of $completed answered'),
    const SizedBox(height: 16), ...questions.map((q) => q.category).toSet().map((category) {
      final s = stats[category] ?? [0, 0];
      final rate = s[0] == 0 ? 0.0 : s[1] / s[0];
      return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(category, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), LinearProgressIndicator(value: rate),
        const SizedBox(height: 5), Text('${s[1]}/${s[0]} correct (${(rate * 100).round()}%)'),
      ])));
    }),
  ]);
}

class QuizView extends StatefulWidget {
  final void Function(Question, bool) onAnswer;
  const QuizView({super.key, required this.onAnswer});
  @override State<QuizView> createState() => _QuizViewState();
}
class _QuizViewState extends State<QuizView> {
  late List<Question> deck;
  int index = 0, score = 0;
  int? selected;
  String category = 'All topics';
  @override void initState() { super.initState(); reset(); }
  void reset() {
    deck = questions.where((q) => category == 'All topics' || q.category == category).toList()..shuffle();
    index = 0; score = 0; selected = null;
  }
  @override Widget build(BuildContext context) {
    final categories = ['All topics', ...questions.map((q) => q.category).toSet()];
    return ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Practice test', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      DropdownButton<String>(isExpanded: true, value: category, items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (v) { if (v != null) setState(() { category = v; reset(); }); }),
      if (index >= deck.length) ...[
        const SizedBox(height: 35), const Icon(Icons.emoji_events_outlined, size: 60),
        Center(child: Text('Finished! $score / ${deck.length} correct', style: const TextStyle(fontSize: 22))),
        const SizedBox(height: 16), FilledButton(onPressed: () => setState(reset), child: const Text('Try another test')),
      ] else ...[
        const SizedBox(height: 14), LinearProgressIndicator(value: index / deck.length),
        const SizedBox(height: 10), Text('Question ${index + 1} of ${deck.length} • $score correct'),
        const SizedBox(height: 25), Text(deck[index].prompt, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        for (var i = 0; i < deck[index].options.length; i++) Padding(padding: const EdgeInsets.only(bottom: 10), child: OutlinedButton(
          onPressed: selected == null ? () { setState(() { selected = i; if (i == deck[index].correct) score++; }); widget.onAnswer(deck[index], i == deck[index].correct); } : null,
          style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16), alignment: Alignment.centerLeft),
          child: Row(children: [Expanded(child: Text(deck[index].options[i])), if (selected != null && i == deck[index].correct) const Icon(Icons.check_circle, color: Colors.green), if (selected == i && i != deck[index].correct) const Icon(Icons.cancel, color: Colors.red)]),
        )),
        if (selected != null) ...[
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(deck[index].explanation))),
          FilledButton(onPressed: () => setState(() { index++; selected = null; }), child: Text(index == deck.length - 1 ? 'View results' : 'Next question')),
        ],
      ],
    ]);
  }
}

class FlashcardsView extends StatefulWidget {
  const FlashcardsView({super.key});
  @override State<FlashcardsView> createState() => _FlashcardsViewState();
}
class _FlashcardsViewState extends State<FlashcardsView> {
  int index = 0;
  bool flipped = false;
  @override Widget build(BuildContext context) {
    final q = questions[index];
    return Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      const Align(alignment: Alignment.centerLeft, child: Text('Flashcards', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
      const SizedBox(height: 12), Text('${index + 1} / ${questions.length} • ${q.category}'),
      Expanded(child: Center(child: GestureDetector(onTap: () => setState(() => flipped = !flipped), child: Card(
        child: SizedBox(width: double.infinity, height: 300, child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(flipped ? 'ANSWER' : 'QUESTION', style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 18),
          Text(flipped ? q.options[q.correct] : q.prompt, textAlign: TextAlign.center, style: const TextStyle(fontSize: 23)),
          const SizedBox(height: 16), Text(flipped ? q.explanation : 'Tap to reveal', textAlign: TextAlign.center),
        ])),
      )))),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        OutlinedButton(onPressed: () => setState(() { index = (index - 1 + questions.length) % questions.length; flipped = false; }), child: const Text('Previous')),
        FilledButton(onPressed: () => setState(() { index = (index + 1) % questions.length; flipped = false; }), child: const Text('Next')),
      ]),
    ]));
  }
}
